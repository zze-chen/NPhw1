key "make" on the command line and execute it,then open firefox and go to url "localhost:8080"
select a file and upload,check the file in the folder
